--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: execute_safe_query(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.execute_safe_query(query_text text, OUT result_json jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    result_rows JSONB;
BEGIN
    -- Execute the query and convert results to JSON
    EXECUTE format('SELECT COALESCE(jsonb_agg(row_to_json(t)), ''[]''::jsonb) FROM (%s) t', query_text)
    INTO result_json;
EXCEPTION WHEN OTHERS THEN
    -- Return error information as JSON
    result_json = jsonb_build_object(
        'error', SQLERRM,
        'detail', SQLSTATE,
        'context', 'Query execution failed'
    );
END;
$$;


ALTER FUNCTION public.execute_safe_query(query_text text, OUT result_json jsonb) OWNER TO postgres;

--
-- Name: get_table_info(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_table_info(OUT table_name text, OUT column_info jsonb) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.table_name::TEXT,
        jsonb_agg(jsonb_build_object(
            'column_name', c.column_name,
            'data_type', c.data_type,
            'is_nullable', c.is_nullable,
            'column_default', c.column_default
        )) AS column_info
    FROM 
        information_schema.tables t
        JOIN information_schema.columns c ON t.table_name = c.table_name
    WHERE 
        t.table_schema = 'public'
        AND t.table_type = 'BASE TABLE'
    GROUP BY 
        t.table_name;
END;
$$;


ALTER FUNCTION public.get_table_info(OUT table_name text, OUT column_info jsonb) OWNER TO postgres;

--
-- Name: get_table_relationships(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_table_relationships(OUT source_table text, OUT target_table text, OUT constraint_name text, OUT constraint_type text) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tc.table_name::TEXT as source_table,
        ccu.table_name::TEXT as target_table,
        tc.constraint_name::TEXT,
        tc.constraint_type::TEXT
    FROM 
        information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu 
            ON tc.constraint_name = ccu.constraint_name
    WHERE 
        tc.table_schema = 'public'
        AND tc.constraint_type IN ('FOREIGN KEY', 'PRIMARY KEY');
END;
$$;


ALTER FUNCTION public.get_table_relationships(OUT source_table text, OUT target_table text, OUT constraint_name text, OUT constraint_type text) OWNER TO postgres;

--
-- Name: get_user_role_summary(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_role_summary(OUT role_type text, OUT user_count bigint, OUT dashboard_count bigint) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        udr.role_type::TEXT,
        COUNT(DISTINCT udr.user_id) as user_count,
        COUNT(DISTINCT udr.dashboard_id) as dashboard_count
    FROM 
        user_dashboard_roles udr
    GROUP BY 
        udr.role_type;
END;
$$;


ALTER FUNCTION public.get_user_role_summary(OUT role_type text, OUT user_count bigint, OUT dashboard_count bigint) OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dashboard_menu_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_menu_items (
    dashboard_id character varying(255) NOT NULL,
    menu_item_id integer NOT NULL,
    is_enabled boolean DEFAULT true,
    order_index integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboard_menu_items OWNER TO postgres;

--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboards (
    id character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    logo character varying(255) NOT NULL,
    plan character varying(50) NOT NULL,
    default_menu_id character varying(255),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboards OWNER TO postgres;

--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_items (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    icon character varying(255),
    url_href character varying(255),
    url_target character varying(10),
    url_rel character varying(50),
    parent_id integer,
    is_collapsible boolean DEFAULT false,
    order_index integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.menu_items OWNER TO postgres;

--
-- Name: menu_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.menu_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.menu_items_id_seq OWNER TO postgres;

--
-- Name: menu_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.menu_items_id_seq OWNED BY public.menu_items.id;


--
-- Name: user_dashboard_roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_dashboard_roles (
    id character varying(255) DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id character varying(255) NOT NULL,
    dashboard_id character varying(255) NOT NULL,
    role_type character varying(20) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_role_type CHECK (((role_type)::text = ANY ((ARRAY['SUPER_ADMIN'::character varying, 'ADMIN'::character varying, 'MANAGER'::character varying, 'USER'::character varying, 'STAFF'::character varying, 'CLIENT'::character varying, 'GUEST'::character varying])::text[])))
);


ALTER TABLE public.user_dashboard_roles OWNER TO postgres;

--
-- Name: user_dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_dashboards (
    id integer NOT NULL,
    user_id character varying(255) NOT NULL,
    dashboard_id character varying(255) NOT NULL,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_dashboards OWNER TO postgres;

--
-- Name: user_dashboards_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_dashboards_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_dashboards_id_seq OWNER TO postgres;

--
-- Name: user_dashboards_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_dashboards_id_seq OWNED BY public.user_dashboards.id;


--
-- Name: user_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_details (
    id character varying(255) DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id character varying(255) NOT NULL,
    avatar_url character varying(255),
    phone character varying(20),
    address_line1 character varying(255),
    address_line2 character varying(255),
    city character varying(100),
    state character varying(100),
    country character varying(100),
    postal_code character varying(20),
    bio text,
    date_of_birth date,
    gender character varying(20),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_details OWNER TO postgres;

--
-- Name: user_preferences; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_preferences (
    id character varying(255) DEFAULT (gen_random_uuid())::text NOT NULL,
    user_id character varying(255) NOT NULL,
    theme character varying(20) DEFAULT 'light'::character varying,
    language character varying(10) DEFAULT 'en'::character varying,
    timezone character varying(50) DEFAULT 'UTC'::character varying,
    notification_settings jsonb DEFAULT '{"push": true, "email": true, "desktop": true}'::jsonb,
    dashboard_layout jsonb DEFAULT '{"density": "comfortable", "sidebar": "expanded"}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_preferences OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(255) DEFAULT (gen_random_uuid())::text NOT NULL,
    username character varying(50) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(50),
    last_name character varying(50),
    is_active boolean DEFAULT true,
    last_login_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: vw_super_admins; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_super_admins AS
 SELECT u.id,
    u.username,
    u.email,
    u.first_name,
    u.last_name,
    d.name AS dashboard_name,
    ud.phone
   FROM (((public.users u
     JOIN public.user_dashboard_roles udr ON (((u.id)::text = (udr.user_id)::text)))
     JOIN public.dashboards d ON (((udr.dashboard_id)::text = (d.id)::text)))
     LEFT JOIN public.user_details ud ON (((u.id)::text = (ud.user_id)::text)))
  WHERE ((u.is_active = true) AND ((udr.role_type)::text = 'SUPER_ADMIN'::text));


ALTER VIEW public.vw_super_admins OWNER TO postgres;

--
-- Name: vw_user_complete; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_user_complete AS
 SELECT u.id,
    u.username,
    u.email,
    u.first_name,
    u.last_name,
    u.is_active,
    ud.avatar_url,
    ud.phone,
    ud.address_line1,
    ud.city,
    ud.country,
    up.theme,
    up.language,
    up.timezone,
    up.notification_settings,
    up.dashboard_layout,
    array_agg(DISTINCT udr.role_type) FILTER (WHERE (udr.role_type IS NOT NULL)) AS roles,
    array_agg(DISTINCT d.name) FILTER (WHERE (d.name IS NOT NULL)) AS dashboard_names
   FROM ((((public.users u
     LEFT JOIN public.user_details ud ON (((u.id)::text = (ud.user_id)::text)))
     LEFT JOIN public.user_preferences up ON (((u.id)::text = (up.user_id)::text)))
     LEFT JOIN public.user_dashboard_roles udr ON (((u.id)::text = (udr.user_id)::text)))
     LEFT JOIN public.dashboards d ON (((udr.dashboard_id)::text = (d.id)::text)))
  GROUP BY u.id, u.username, u.email, u.first_name, u.last_name, u.is_active, ud.avatar_url, ud.phone, ud.address_line1, ud.city, ud.country, up.theme, up.language, up.timezone, up.notification_settings, up.dashboard_layout;


ALTER VIEW public.vw_user_complete OWNER TO postgres;

--
-- Name: vw_user_dashboard_access; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.vw_user_dashboard_access AS
 SELECT u.id AS user_id,
    u.username,
    u.email,
    d.id AS dashboard_id,
    d.name AS dashboard_name,
    udr.role_type,
    u.is_active
   FROM ((public.users u
     JOIN public.user_dashboard_roles udr ON (((u.id)::text = (udr.user_id)::text)))
     JOIN public.dashboards d ON (((udr.dashboard_id)::text = (d.id)::text)));


ALTER VIEW public.vw_user_dashboard_access OWNER TO postgres;

--
-- Name: menu_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items ALTER COLUMN id SET DEFAULT nextval('public.menu_items_id_seq'::regclass);


--
-- Name: user_dashboards id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboards ALTER COLUMN id SET DEFAULT nextval('public.user_dashboards_id_seq'::regclass);


--
-- Data for Name: dashboard_menu_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_menu_items (dashboard_id, menu_item_id, is_enabled, order_index, created_at) FROM stdin;
main	1	t	1	2025-01-25 13:02:01.30927
home	1	t	1	2025-01-25 13:02:01.30927
professional	1	t	1	2025-01-25 13:02:01.30927
study	1	t	1	2025-01-25 13:02:01.30927
health	1	t	1	2025-01-25 13:02:01.30927
travel	1	t	1	2025-01-25 13:02:01.30927
family	1	t	1	2025-01-25 13:02:01.30927
finance	1	t	1	2025-01-25 13:02:01.30927
hobbies	1	t	1	2025-01-25 13:02:01.30927
digital	1	t	1	2025-01-25 13:02:01.30927
personal	1	t	1	2025-01-25 13:02:01.30927
main	2	t	2	2025-01-25 13:02:01.30927
home	2	t	2	2025-01-25 13:02:01.30927
professional	2	t	2	2025-01-25 13:02:01.30927
study	2	t	2	2025-01-25 13:02:01.30927
health	2	t	2	2025-01-25 13:02:01.30927
travel	2	t	2	2025-01-25 13:02:01.30927
family	2	t	2	2025-01-25 13:02:01.30927
finance	2	t	2	2025-01-25 13:02:01.30927
hobbies	2	t	2	2025-01-25 13:02:01.30927
digital	2	t	2	2025-01-25 13:02:01.30927
personal	2	t	2	2025-01-25 13:02:01.30927
main	3	t	3	2025-01-25 13:02:01.30927
home	3	t	3	2025-01-25 13:02:01.30927
professional	3	t	3	2025-01-25 13:02:01.30927
study	3	t	3	2025-01-25 13:02:01.30927
health	3	t	3	2025-01-25 13:02:01.30927
travel	3	t	3	2025-01-25 13:02:01.30927
family	3	t	3	2025-01-25 13:02:01.30927
finance	3	t	3	2025-01-25 13:02:01.30927
hobbies	3	t	3	2025-01-25 13:02:01.30927
digital	3	t	3	2025-01-25 13:02:01.30927
personal	3	t	3	2025-01-25 13:02:01.30927
main	4	t	4	2025-01-25 13:02:01.30927
home	4	t	4	2025-01-25 13:02:01.30927
professional	4	t	4	2025-01-25 13:02:01.30927
study	4	t	4	2025-01-25 13:02:01.30927
health	4	t	4	2025-01-25 13:02:01.30927
travel	4	t	4	2025-01-25 13:02:01.30927
family	4	t	4	2025-01-25 13:02:01.30927
finance	4	t	4	2025-01-25 13:02:01.30927
hobbies	4	t	4	2025-01-25 13:02:01.30927
digital	4	t	4	2025-01-25 13:02:01.30927
personal	4	t	4	2025-01-25 13:02:01.30927
main	5	t	5	2025-01-25 13:02:01.30927
home	5	t	5	2025-01-25 13:02:01.30927
professional	5	t	5	2025-01-25 13:02:01.30927
study	5	t	5	2025-01-25 13:02:01.30927
health	5	t	5	2025-01-25 13:02:01.30927
travel	5	t	5	2025-01-25 13:02:01.30927
family	5	t	5	2025-01-25 13:02:01.30927
finance	5	t	5	2025-01-25 13:02:01.30927
hobbies	5	t	5	2025-01-25 13:02:01.30927
digital	5	t	5	2025-01-25 13:02:01.30927
personal	5	t	5	2025-01-25 13:02:01.30927
main	6	t	6	2025-01-25 13:02:01.30927
home	6	t	6	2025-01-25 13:02:01.30927
professional	6	t	6	2025-01-25 13:02:01.30927
study	6	t	6	2025-01-25 13:02:01.30927
health	6	t	6	2025-01-25 13:02:01.30927
travel	6	t	6	2025-01-25 13:02:01.30927
family	6	t	6	2025-01-25 13:02:01.30927
finance	6	t	6	2025-01-25 13:02:01.30927
hobbies	6	t	6	2025-01-25 13:02:01.30927
digital	6	t	6	2025-01-25 13:02:01.30927
personal	6	t	6	2025-01-25 13:02:01.30927
main	7	t	7	2025-01-25 13:02:01.30927
home	7	t	7	2025-01-25 13:02:01.30927
professional	7	t	7	2025-01-25 13:02:01.30927
study	7	t	7	2025-01-25 13:02:01.30927
health	7	t	7	2025-01-25 13:02:01.30927
travel	7	t	7	2025-01-25 13:02:01.30927
family	7	t	7	2025-01-25 13:02:01.30927
finance	7	t	7	2025-01-25 13:02:01.30927
hobbies	7	t	7	2025-01-25 13:02:01.30927
digital	7	t	7	2025-01-25 13:02:01.30927
personal	7	t	7	2025-01-25 13:02:01.30927
main	8	t	8	2025-01-25 13:02:01.30927
home	8	t	8	2025-01-25 13:02:01.30927
professional	8	t	8	2025-01-25 13:02:01.30927
study	8	t	8	2025-01-25 13:02:01.30927
health	8	t	8	2025-01-25 13:02:01.30927
travel	8	t	8	2025-01-25 13:02:01.30927
family	8	t	8	2025-01-25 13:02:01.30927
finance	8	t	8	2025-01-25 13:02:01.30927
hobbies	8	t	8	2025-01-25 13:02:01.30927
digital	8	t	8	2025-01-25 13:02:01.30927
personal	8	t	8	2025-01-25 13:02:01.30927
main	9	t	9	2025-01-25 13:02:01.30927
home	9	t	9	2025-01-25 13:02:01.30927
professional	9	t	9	2025-01-25 13:02:01.30927
study	9	t	9	2025-01-25 13:02:01.30927
health	9	t	9	2025-01-25 13:02:01.30927
travel	9	t	9	2025-01-25 13:02:01.30927
family	9	t	9	2025-01-25 13:02:01.30927
finance	9	t	9	2025-01-25 13:02:01.30927
hobbies	9	t	9	2025-01-25 13:02:01.30927
digital	9	t	9	2025-01-25 13:02:01.30927
personal	9	t	9	2025-01-25 13:02:01.30927
\.


--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboards (id, name, logo, plan, default_menu_id, created_at, updated_at) FROM stdin;
main	Main	layout-dashboard	Personal	main	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
home	Home	home	Personal	home	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
professional	Professional	briefcase	Professional	professional	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
study	Study	graduation-cap	Personal	study	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
health	Health	heart	Personal	health	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
travel	Travel	plane	Personal	travel	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
family	Family	users	Personal	family	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
finance	Finance	wallet	Professional	finance	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
hobbies	Hobbies	gamepad-2	Personal	hobbies	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
digital	Digital	building-2	Professional	digital	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
personal	Personal	user	Personal	personal	2025-01-25 12:12:19.253639	2025-01-25 12:12:19.253639
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_items (id, title, icon, url_href, url_target, url_rel, parent_id, is_collapsible, order_index, created_at, updated_at) FROM stdin;
1	Dashboard	LayoutDashboard	/dashboard	_self	\N	\N	f	1	2025-01-25 12:45:04.683883	2025-01-25 12:45:04.683883
2	Analyze	BarChart2	/dashboard/analyze	_self	\N	\N	f	2	2025-01-25 12:45:04.683883	2025-01-25 12:45:04.683883
3	Menu Store	Store	/dashboard/menu-store	_self	\N	\N	f	3	2025-01-25 12:45:04.683883	2025-01-25 12:45:04.683883
4	Database Management	Database	/dashboard/database-manager	_self	\N	\N	f	4	2025-01-25 12:45:04.683883	2025-01-25 12:45:04.683883
5	Social Media	Share2	\N	_self	\N	\N	t	5	2025-01-25 12:45:04.683883	2025-01-25 12:45:04.683883
6	Overview	LayoutDashboard	/dashboard/social-media/overview	_self	\N	5	f	1	2025-01-25 12:45:04.945489	2025-01-25 12:45:04.945489
7	Posts	Inbox	/dashboard/social-media/posts	_self	\N	5	f	2	2025-01-25 12:45:04.945489	2025-01-25 12:45:04.945489
8	Calendar	Calendar	/dashboard/social-media/calendar	_self	\N	5	f	3	2025-01-25 12:45:04.945489	2025-01-25 12:45:04.945489
9	Analytics	BarChart	/dashboard/social-media/analytics	_self	\N	5	f	4	2025-01-25 12:45:04.945489	2025-01-25 12:45:04.945489
\.


--
-- Data for Name: user_dashboard_roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_dashboard_roles (id, user_id, dashboard_id, role_type, created_at, updated_at) FROM stdin;
6b8a79c8-57ac-47d3-b0e2-47b1e0c1b20e	ca98ac02-862a-4a60-974d-7cbb6fec56eb	main	SUPER_ADMIN	2025-01-26 09:24:09.651093	2025-01-26 09:24:09.651093
\.


--
-- Data for Name: user_dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_dashboards (id, user_id, dashboard_id, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: user_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_details (id, user_id, avatar_url, phone, address_line1, address_line2, city, state, country, postal_code, bio, date_of_birth, gender, created_at, updated_at) FROM stdin;
385e1e84-4610-4c5c-945c-5639fcc57e11	ca98ac02-862a-4a60-974d-7cbb6fec56eb	https://example.com/avatar.jpg	+1234567890	123 Main St	\N	New York	\N	USA	\N	\N	\N	\N	2025-01-26 09:24:09.651093	2025-01-26 09:24:09.651093
\.


--
-- Data for Name: user_preferences; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_preferences (id, user_id, theme, language, timezone, notification_settings, dashboard_layout, created_at, updated_at) FROM stdin;
2c5da18a-4072-4fe1-8fb0-4dbba0e3b9ac	ca98ac02-862a-4a60-974d-7cbb6fec56eb	light	en	UTC	{"push": true, "email": true, "desktop": true}	{"density": "comfortable", "sidebar": "expanded"}	2025-01-26 09:24:09.651093	2025-01-26 09:24:09.651093
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, email, password_hash, first_name, last_name, is_active, last_login_at, created_at, updated_at) FROM stdin;
ca98ac02-862a-4a60-974d-7cbb6fec56eb	johndoe	john@example.com	hashed_password	John	Doe	t	\N	2025-01-26 09:24:09.651093	2025-01-26 09:24:09.651093
\.


--
-- Name: menu_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.menu_items_id_seq', 9, true);


--
-- Name: user_dashboards_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_dashboards_id_seq', 1, false);


--
-- Name: dashboard_menu_items dashboard_menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_menu_items
    ADD CONSTRAINT dashboard_menu_items_pkey PRIMARY KEY (dashboard_id, menu_item_id);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: user_dashboard_roles user_dashboard_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboard_roles
    ADD CONSTRAINT user_dashboard_roles_pkey PRIMARY KEY (id);


--
-- Name: user_dashboard_roles user_dashboard_roles_user_id_dashboard_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboard_roles
    ADD CONSTRAINT user_dashboard_roles_user_id_dashboard_id_key UNIQUE (user_id, dashboard_id);


--
-- Name: user_dashboards user_dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboards
    ADD CONSTRAINT user_dashboards_pkey PRIMARY KEY (id);


--
-- Name: user_dashboards user_dashboards_user_id_dashboard_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboards
    ADD CONSTRAINT user_dashboards_user_id_dashboard_id_key UNIQUE (user_id, dashboard_id);


--
-- Name: user_details user_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_pkey PRIMARY KEY (id);


--
-- Name: user_details user_details_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_user_id_key UNIQUE (user_id);


--
-- Name: user_preferences user_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_pkey PRIMARY KEY (id);


--
-- Name: user_preferences user_preferences_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_user_dashboard_roles_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dashboard_roles_dashboard_id ON public.user_dashboard_roles USING btree (dashboard_id);


--
-- Name: idx_user_dashboard_roles_role_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dashboard_roles_role_type ON public.user_dashboard_roles USING btree (role_type);


--
-- Name: idx_user_dashboard_roles_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_dashboard_roles_user_id ON public.user_dashboard_roles USING btree (user_id);


--
-- Name: idx_user_details_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_details_user_id ON public.user_details USING btree (user_id);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: user_dashboard_roles update_user_dashboard_roles_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_dashboard_roles_updated_at BEFORE UPDATE ON public.user_dashboard_roles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_details update_user_details_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_user_details_updated_at BEFORE UPDATE ON public.user_details FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dashboard_menu_items dashboard_menu_items_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_menu_items
    ADD CONSTRAINT dashboard_menu_items_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: dashboard_menu_items dashboard_menu_items_menu_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_menu_items
    ADD CONSTRAINT dashboard_menu_items_menu_item_id_fkey FOREIGN KEY (menu_item_id) REFERENCES public.menu_items(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.menu_items(id) ON DELETE CASCADE;


--
-- Name: user_dashboard_roles user_dashboard_roles_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboard_roles
    ADD CONSTRAINT user_dashboard_roles_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: user_dashboard_roles user_dashboard_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_dashboard_roles
    ADD CONSTRAINT user_dashboard_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_details user_details_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_preferences user_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_preferences
    ADD CONSTRAINT user_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


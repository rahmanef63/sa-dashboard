--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: create_default_dashboards_for_user(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_default_dashboards_for_user(user_id uuid) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    dashboard_id UUID;
BEGIN
    -- Main Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Main', 'layout-dashboard', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'main-menu', 'Main Menu', 'main', true);

    -- Home Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Home', 'home', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'home-menu', 'Home Menu', 'home');

    -- Professional Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Professional', 'briefcase', 'Professional', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'professional-menu', 'Professional Menu', 'professional');

    -- Study Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Study', 'graduation-cap', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'study-menu', 'Study Menu', 'study');

    -- Health Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Health', 'heart', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'health-menu', 'Health Menu', 'health');

    -- Travel Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Travel', 'plane', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'travel-menu', 'Travel Menu', 'travel');

    -- Family Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Family', 'users', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'family-menu', 'Family Menu', 'family');

    -- Finance Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Finance', 'wallet', 'Professional', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'finance-menu', 'Finance Menu', 'finance');

    -- Hobbies Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Hobbies', 'palette', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'hobbies-menu', 'Hobbies Menu', 'hobbies');

    -- Digital Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Digital', 'monitor', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'digital-menu', 'Digital Menu', 'digital');

    -- Personal Dashboard
    INSERT INTO dashboards (id, name, logo, plan, is_active, user_id)
    VALUES (uuid_generate_v4(), 'Personal', 'user', 'Personal', true, user_id)
    RETURNING id INTO dashboard_id;
    
    PERFORM create_default_menu_items(dashboard_id, 'personal-menu', 'Personal Menu', 'personal');

    RAISE NOTICE 'Created default dashboards for user %', user_id;
END;
$$;


ALTER FUNCTION public.create_default_dashboards_for_user(user_id uuid) OWNER TO postgres;

--
-- Name: create_default_dashboards_trigger(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_default_dashboards_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM create_default_dashboards_for_user(NEW.id);
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.create_default_dashboards_trigger() OWNER TO postgres;

--
-- Name: create_default_menu_items(uuid, character varying, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_default_menu_items(dashboard_id uuid, menu_type character varying, is_default boolean) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    menu_header_id UUID;
BEGIN
    -- Create menu header
    INSERT INTO menu_items (
        dashboard_id, name, menu_type, is_default, 
        is_menu_header, order_index
    )
    VALUES (
        dashboard_id, 
        CASE menu_type
            WHEN 'main' THEN 'Main Menu'
            WHEN 'home' THEN 'Home Menu'
            WHEN 'professional' THEN 'Professional Menu'
            WHEN 'study' THEN 'Study Menu'
            WHEN 'health' THEN 'Health Menu'
            WHEN 'travel' THEN 'Travel Menu'
            WHEN 'family' THEN 'Family Menu'
            WHEN 'finance' THEN 'Finance Menu'
            WHEN 'hobbies' THEN 'Hobbies Menu'
            WHEN 'digital' THEN 'Digital Menu'
            WHEN 'personal' THEN 'Personal Menu'
            ELSE menu_type || ' Menu'
        END,
        menu_type,
        is_default,
        true,
        0
    )
    RETURNING id INTO menu_header_id;

    -- Add default menu items under the header
    INSERT INTO menu_items (
        dashboard_id, parent_id, name, icon, url,
        menu_type, is_default, is_menu_header, order_index
    )
    VALUES
    (dashboard_id, menu_header_id, 'Overview', 'layout-dashboard', '/', menu_type, false, false, 1),
    (dashboard_id, menu_header_id, 'Settings', 'settings', '/settings', menu_type, false, false, 2);

    RAISE NOTICE 'Created default menu items for dashboard %', dashboard_id;
END;
$$;


ALTER FUNCTION public.create_default_menu_items(dashboard_id uuid, menu_type character varying, is_default boolean) OWNER TO postgres;

--
-- Name: create_default_menu_items(uuid, character varying, character varying, character varying, boolean); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.create_default_menu_items(dashboard_id uuid, menu_id character varying, menu_name character varying, menu_type character varying, is_default boolean DEFAULT false) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    menu_header_id VARCHAR(50);
BEGIN
    -- Create menu header
    menu_header_id := menu_id || '-header';
    
    INSERT INTO menu_items (
        id, dashboard_id, menu_id, title, menu_type, 
        is_default, is_menu_header, order_index
    )
    VALUES (
        menu_header_id,
        dashboard_id,
        menu_id,
        menu_name,
        menu_type,
        is_default,
        true,
        0
    );

    -- Add Personal Nav Items
    IF menu_type = 'personal' THEN
        -- Schedule
        INSERT INTO menu_items (
            id, dashboard_id, parent_id, menu_id, title, 
            icon, url_href, menu_type, is_default, 
            is_menu_header, order_index
        )
        VALUES (
            'personal-schedule',
            dashboard_id,
            menu_header_id,
            menu_id,
            'Daily Schedule',
            'Calendar',
            '/personal/schedule',
            menu_type,
            false,
            false,
            1
        );
    END IF;

    RAISE NOTICE 'Created default menu items for dashboard % with menu %', dashboard_id, menu_id;
END;
$$;


ALTER FUNCTION public.create_default_menu_items(dashboard_id uuid, menu_id character varying, menu_name character varying, menu_type character varying, is_default boolean) OWNER TO postgres;

--
-- Name: execute_safe_query(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.execute_safe_query(query_text text, OUT result_json jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    result_rows JSONB;
BEGIN
    -- Execute the query and convert results to JSON
    EXECUTE format('SELECT COALESCE(jsonb_agg(row_to_json(t)), ''[]''::jsonb) FROM (%s) t', query_text)
    INTO result_json;
EXCEPTION WHEN OTHERS THEN
    -- Return error information as JSON
    result_json = jsonb_build_object(
        'error', SQLERRM,
        'detail', SQLSTATE,
        'context', 'Query execution failed'
    );
END;
$$;


ALTER FUNCTION public.execute_safe_query(query_text text, OUT result_json jsonb) OWNER TO postgres;

--
-- Name: get_table_info(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_table_info(OUT table_name text, OUT column_info jsonb) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.table_name::TEXT,
        jsonb_agg(jsonb_build_object(
            'column_name', c.column_name,
            'data_type', c.data_type,
            'is_nullable', c.is_nullable,
            'column_default', c.column_default
        )) AS column_info
    FROM 
        information_schema.tables t
        JOIN information_schema.columns c ON t.table_name = c.table_name
    WHERE 
        t.table_schema = 'public'
        AND t.table_type = 'BASE TABLE'
    GROUP BY 
        t.table_name;
END;
$$;


ALTER FUNCTION public.get_table_info(OUT table_name text, OUT column_info jsonb) OWNER TO postgres;

--
-- Name: get_table_relationships(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_table_relationships(OUT source_table text, OUT target_table text, OUT constraint_name text, OUT constraint_type text) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tc.table_name::TEXT as source_table,
        ccu.table_name::TEXT as target_table,
        tc.constraint_name::TEXT,
        tc.constraint_type::TEXT
    FROM 
        information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu 
            ON tc.constraint_name = ccu.constraint_name
    WHERE 
        tc.table_schema = 'public'
        AND tc.constraint_type IN ('FOREIGN KEY', 'PRIMARY KEY');
END;
$$;


ALTER FUNCTION public.get_table_relationships(OUT source_table text, OUT target_table text, OUT constraint_name text, OUT constraint_type text) OWNER TO postgres;

--
-- Name: get_user_role_summary(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_role_summary(OUT role_type text, OUT user_count bigint, OUT dashboard_count bigint) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        udr.role_type::TEXT,
        COUNT(DISTINCT udr.user_id) as user_count,
        COUNT(DISTINCT udr.dashboard_id) as dashboard_count
    FROM 
        user_dashboard_roles udr
    GROUP BY 
        udr.role_type;
END;
$$;


ALTER FUNCTION public.get_user_role_summary(OUT role_type text, OUT user_count bigint, OUT dashboard_count bigint) OWNER TO postgres;

--
-- Name: insert_menu_item(character varying, uuid, character varying, character varying, character varying, character varying, character varying, character varying, boolean, boolean, boolean, integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.insert_menu_item(p_menu_key character varying, p_dashboard_id uuid, p_parent_key character varying, p_menu_id character varying, p_title character varying, p_icon character varying, p_url_href character varying, p_menu_type character varying, p_is_default boolean DEFAULT true, p_is_menu_header boolean DEFAULT false, p_is_collapsible boolean DEFAULT false, p_order_index integer DEFAULT 1) RETURNS uuid
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_id UUID;
    v_parent_id UUID;
BEGIN
    -- Generate a deterministic UUID based on the menu_key
    v_id := uuid_generate_v5(uuid_ns_url(), p_menu_key);
    
    -- If parent_key is provided, get its UUID
    IF p_parent_key IS NOT NULL THEN
        v_parent_id := uuid_generate_v5(uuid_ns_url(), p_parent_key);
    END IF;

    INSERT INTO menu_items (
        id, dashboard_id, parent_id, menu_id, title, 
        icon, url_href, menu_type, is_default, 
        is_menu_header, is_collapsible, order_index
    ) VALUES (
        v_id, p_dashboard_id, v_parent_id, p_menu_id, p_title,
        p_icon, p_url_href, p_menu_type, p_is_default,
        p_is_menu_header, p_is_collapsible, p_order_index
    )
    ON CONFLICT (id) DO UPDATE SET
        dashboard_id = EXCLUDED.dashboard_id,
        parent_id = EXCLUDED.parent_id,
        menu_id = EXCLUDED.menu_id,
        title = EXCLUDED.title,
        icon = EXCLUDED.icon,
        url_href = EXCLUDED.url_href,
        menu_type = EXCLUDED.menu_type,
        is_default = EXCLUDED.is_default,
        is_menu_header = EXCLUDED.is_menu_header,
        is_collapsible = EXCLUDED.is_collapsible,
        order_index = EXCLUDED.order_index;
    
    RETURN v_id;
END;
$$;


ALTER FUNCTION public.insert_menu_item(p_menu_key character varying, p_dashboard_id uuid, p_parent_key character varying, p_menu_id character varying, p_title character varying, p_icon character varying, p_url_href character varying, p_menu_type character varying, p_is_default boolean, p_is_menu_header boolean, p_is_collapsible boolean, p_order_index integer) OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboards (
    id uuid NOT NULL,
    name character varying(255) NOT NULL,
    logo character varying(255),
    plan character varying(50) NOT NULL,
    is_active boolean DEFAULT true,
    user_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    is_default_dashboard boolean DEFAULT false
);


ALTER TABLE public.dashboards OWNER TO postgres;

--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_items (
    id uuid NOT NULL,
    dashboard_id uuid NOT NULL,
    parent_id uuid,
    menu_id character varying(50) NOT NULL,
    title character varying(255) NOT NULL,
    icon character varying(255),
    url_href character varying(255),
    menu_type character varying(50) NOT NULL,
    is_default boolean DEFAULT false,
    is_menu_header boolean DEFAULT false,
    is_collapsible boolean DEFAULT false,
    order_index integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.menu_items OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    dashboard_ids uuid[] DEFAULT '{}'::uuid[],
    dashboard_roles text[] DEFAULT '{}'::text[]
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboards (id, name, logo, plan, is_active, user_id, created_at, updated_at, is_default_dashboard) FROM stdin;
262d9181-0973-4f54-b7c6-869b917b1844	Personal	layout-dashboard	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-30 16:58:11.826+00	2025-01-30 16:58:11.826+00	t
6c693c05-b213-4d7f-8cb8-873d39d8146d	Main	layout-dashboard	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-30 16:58:11.826845+00	2025-01-30 16:58:11.826845+00	t
842f256d-8b0a-42d5-b64a-d5b9be7ad7b8	Home	home	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
cce46a2c-2f63-466e-9cce-0d8b8a15d5c6	Professional	briefcase	Professional	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
e54682a9-67ce-4a1d-9e83-2278802644e0	Study	graduation-cap	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
cd55108a-7b69-46d0-8752-f7a01fd7ac53	Health	heart	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
695b8d27-02c9-4645-a6aa-878c48d0f132	Travel	plane	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
45c4926a-231c-4187-b4a5-7a78ccd88cb6	Family	users	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
ddcabf98-229d-4cbe-855f-8bb85a816836	Finance	wallet	Professional	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
ac268cea-3f55-42d9-8c96-d16339dc6032	Hobbies	palette	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
19af0b4f-d8d2-49f8-8406-1727311469b9	Digital	monitor	Personal	t	a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	2025-01-31 09:15:20.213116+00	2025-01-31 09:15:20.213116+00	t
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_items (id, dashboard_id, parent_id, menu_id, title, icon, url_href, menu_type, is_default, is_menu_header, is_collapsible, order_index, created_at, updated_at) FROM stdin;
45ef7aaf-7176-5579-804c-ac273daadaf2	262d9181-0973-4f54-b7c6-869b917b1844	\N	family-nav	Family Calendar	Calendar	/family/calendar	family	t	f	f	1	2025-01-31 08:39:19.910672+00	2025-01-31 08:39:19.910672+00
d8d33c69-a7c7-5716-a84d-bc766d89f996	262d9181-0973-4f54-b7c6-869b917b1844	\N	family-nav	Family Tasks	CheckSquare	/family/tasks	family	t	f	f	2	2025-01-31 08:39:19.910672+00	2025-01-31 08:39:19.910672+00
bbc6f979-d445-5ff0-aec8-1fa2cfab9892	262d9181-0973-4f54-b7c6-869b917b1844	\N	family-nav	Family Photos	Image	/family/photos	family	t	f	f	3	2025-01-31 08:39:19.910672+00	2025-01-31 08:39:19.910672+00
7dd9df5d-2050-5ac2-8727-7d2092bac27b	262d9181-0973-4f54-b7c6-869b917b1844	\N	family-nav	Family Contacts	Users	/family/contacts	family	t	f	f	4	2025-01-31 08:39:19.910672+00	2025-01-31 08:39:19.910672+00
3c6b1d21-c9e9-5d76-b896-b6e8b3ac7486	262d9181-0973-4f54-b7c6-869b917b1844	\N	family-nav	Family Events	PartyPopper	/family/events	family	t	f	f	5	2025-01-31 08:39:19.910672+00	2025-01-31 08:39:19.910672+00
b5321ee6-19e6-531c-85de-c7a04acd2c1d	262d9181-0973-4f54-b7c6-869b917b1844	\N	digital-nav	Password Manager	Lock	/digital/passwords	digital	t	f	f	1	2025-01-31 08:39:11.264676+00	2025-01-31 08:39:11.264676+00
66c6ed5b-7849-5bb1-ace5-c937abbe4b7b	262d9181-0973-4f54-b7c6-869b917b1844	\N	digital-nav	Cloud Storage	Cloud	/digital/storage	digital	t	f	f	2	2025-01-31 08:39:11.264676+00	2025-01-31 08:39:11.264676+00
9f6771c4-0c6c-5bd9-8d91-14888aedba52	262d9181-0973-4f54-b7c6-869b917b1844	\N	digital-nav	Device Management	Smartphone	/digital/devices	digital	t	f	f	3	2025-01-31 08:39:11.264676+00	2025-01-31 08:39:11.264676+00
8ff203b0-8ad2-59ee-9927-63734bac261a	262d9181-0973-4f54-b7c6-869b917b1844	\N	digital-nav	Digital Assets	Database	/digital/assets	digital	t	f	f	4	2025-01-31 08:39:11.264676+00	2025-01-31 08:39:11.264676+00
492d0b1b-d206-555c-a3ed-d7cde9916307	262d9181-0973-4f54-b7c6-869b917b1844	\N	digital-nav	Subscriptions	RefreshCw	/digital/subscriptions	digital	t	f	f	5	2025-01-31 08:39:11.264676+00	2025-01-31 08:39:11.264676+00
67655ee6-0513-5f49-81f7-a5d4620e2cb5	262d9181-0973-4f54-b7c6-869b917b1844	\N	digital-nav	Backup Status	Save	/digital/backup	digital	t	f	f	6	2025-01-31 08:39:11.264676+00	2025-01-31 08:39:11.264676+00
b0f6a411-e8bc-5655-854a-15f62b95af49	262d9181-0973-4f54-b7c6-869b917b1844	\N	finance-nav	Financial Overview	PieChart	/finance/dashboard	finance	t	f	f	1	2025-01-31 08:39:42.6563+00	2025-01-31 08:39:42.6563+00
e4f0738e-3b3a-5688-a5c2-c5dc5e9a4109	262d9181-0973-4f54-b7c6-869b917b1844	\N	finance-nav	Budget Planning	Calculator	/finance/budget	finance	t	f	f	2	2025-01-31 08:39:42.6563+00	2025-01-31 08:39:42.6563+00
aeaced8a-947f-509a-b780-1bb0fb457499	262d9181-0973-4f54-b7c6-869b917b1844	\N	finance-nav	Investments	TrendingUp	/finance/investments	finance	t	f	f	3	2025-01-31 08:39:42.6563+00	2025-01-31 08:39:42.6563+00
9c0b3cc6-a77a-53ad-aa8e-c35ab7a7aade	262d9181-0973-4f54-b7c6-869b917b1844	\N	finance-nav	Expenses	CreditCard	/finance/expenses	finance	t	f	f	4	2025-01-31 08:39:42.6563+00	2025-01-31 08:39:42.6563+00
89fcab50-333c-5867-8d7f-aa537fdbd33c	262d9181-0973-4f54-b7c6-869b917b1844	\N	finance-nav	Financial Reports	FileText	/finance/reports	finance	t	f	f	5	2025-01-31 08:39:42.6563+00	2025-01-31 08:39:42.6563+00
5167c784-de89-50ef-acba-44abaee26d57	262d9181-0973-4f54-b7c6-869b917b1844	\N	finance-nav	Financial Goals	Target	/finance/goals	finance	t	f	f	6	2025-01-31 08:39:42.6563+00	2025-01-31 08:39:42.6563+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, role, created_at, updated_at, dashboard_ids, dashboard_roles) FROM stdin;
a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	admin@example.com	Admin User	admin	2025-01-30 16:58:11.826845+00	2025-01-30 16:58:11.826845+00	{262d9181-0973-4f54-b7c6-869b917b1844,6c693c05-b213-4d7f-8cb8-873d39d8146d,842f256d-8b0a-42d5-b64a-d5b9be7ad7b8,cce46a2c-2f63-466e-9cce-0d8b8a15d5c6,e54682a9-67ce-4a1d-9e83-2278802644e0,cd55108a-7b69-46d0-8752-f7a01fd7ac53,695b8d27-02c9-4645-a6aa-878c48d0f132,45c4926a-231c-4187-b4a5-7a78ccd88cb6,ddcabf98-229d-4cbe-855f-8bb85a816836,ac268cea-3f55-42d9-8c96-d16339dc6032,19af0b4f-d8d2-49f8-8406-1727311469b9}	{admin,admin,admin,admin,admin,admin,admin,admin,admin,admin,admin}
\.


--
-- Name: dashboards dashboards_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_name_key UNIQUE (name);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_dashboards_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboards_user_id ON public.dashboards USING btree (user_id);


--
-- Name: idx_menu_items_dashboard; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_dashboard ON public.menu_items USING btree (dashboard_id);


--
-- Name: idx_menu_items_menu_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_menu_id ON public.menu_items USING btree (menu_id);


--
-- Name: idx_menu_items_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_order ON public.menu_items USING btree (order_index);


--
-- Name: idx_menu_items_parent; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_parent ON public.menu_items USING btree (parent_id);


--
-- Name: users create_default_dashboards_on_user_creation; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_default_dashboards_on_user_creation AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.create_default_dashboards_trigger();


--
-- Name: users create_default_dashboards_on_user_insert; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER create_default_dashboards_on_user_insert AFTER INSERT ON public.users FOR EACH ROW EXECUTE FUNCTION public.create_default_dashboards_trigger();


--
-- Name: dashboards dashboards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.menu_items(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--


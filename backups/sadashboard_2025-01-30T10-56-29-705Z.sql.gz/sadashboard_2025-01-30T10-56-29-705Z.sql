--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: execute_safe_query(text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.execute_safe_query(query_text text, OUT result_json jsonb) RETURNS jsonb
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    result_rows JSONB;
BEGIN
    -- Execute the query and convert results to JSON
    EXECUTE format('SELECT COALESCE(jsonb_agg(row_to_json(t)), ''[]''::jsonb) FROM (%s) t', query_text)
    INTO result_json;
EXCEPTION WHEN OTHERS THEN
    -- Return error information as JSON
    result_json = jsonb_build_object(
        'error', SQLERRM,
        'detail', SQLSTATE,
        'context', 'Query execution failed'
    );
END;
$$;


ALTER FUNCTION public.execute_safe_query(query_text text, OUT result_json jsonb) OWNER TO postgres;

--
-- Name: get_table_info(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_table_info(OUT table_name text, OUT column_info jsonb) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.table_name::TEXT,
        jsonb_agg(jsonb_build_object(
            'column_name', c.column_name,
            'data_type', c.data_type,
            'is_nullable', c.is_nullable,
            'column_default', c.column_default
        )) AS column_info
    FROM 
        information_schema.tables t
        JOIN information_schema.columns c ON t.table_name = c.table_name
    WHERE 
        t.table_schema = 'public'
        AND t.table_type = 'BASE TABLE'
    GROUP BY 
        t.table_name;
END;
$$;


ALTER FUNCTION public.get_table_info(OUT table_name text, OUT column_info jsonb) OWNER TO postgres;

--
-- Name: get_table_relationships(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_table_relationships(OUT source_table text, OUT target_table text, OUT constraint_name text, OUT constraint_type text) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        tc.table_name::TEXT as source_table,
        ccu.table_name::TEXT as target_table,
        tc.constraint_name::TEXT,
        tc.constraint_type::TEXT
    FROM 
        information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu 
            ON tc.constraint_name = ccu.constraint_name
    WHERE 
        tc.table_schema = 'public'
        AND tc.constraint_type IN ('FOREIGN KEY', 'PRIMARY KEY');
END;
$$;


ALTER FUNCTION public.get_table_relationships(OUT source_table text, OUT target_table text, OUT constraint_name text, OUT constraint_type text) OWNER TO postgres;

--
-- Name: get_user_role_summary(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_role_summary(OUT role_type text, OUT user_count bigint, OUT dashboard_count bigint) RETURNS SETOF record
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        udr.role_type::TEXT,
        COUNT(DISTINCT udr.user_id) as user_count,
        COUNT(DISTINCT udr.dashboard_id) as dashboard_count
    FROM 
        user_dashboard_roles udr
    GROUP BY 
        udr.role_type;
END;
$$;


ALTER FUNCTION public.get_user_role_summary(OUT role_type text, OUT user_count bigint, OUT dashboard_count bigint) OWNER TO postgres;

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dashboard_users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboard_users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dashboard_id uuid,
    user_id uuid,
    role character varying(50) DEFAULT 'viewer'::character varying,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboard_users OWNER TO postgres;

--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboards (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    logo character varying(255) DEFAULT 'layout-dashboard'::character varying,
    plan character varying(50) DEFAULT 'Personal'::character varying,
    is_public boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    user_id uuid
);


ALTER TABLE public.dashboards OWNER TO postgres;

--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dashboard_id uuid,
    parent_id uuid,
    title character varying(255) NOT NULL,
    icon character varying(255),
    url_href character varying(255),
    order_index integer DEFAULT 0,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    menu_id uuid,
    is_collapsible boolean DEFAULT false
);


ALTER TABLE public.menu_items OWNER TO postgres;

--
-- Name: menus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menus (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dashboard_id uuid,
    name character varying(255) NOT NULL,
    icon character varying(255),
    menu_type character varying(50) NOT NULL,
    is_default boolean DEFAULT false,
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by uuid,
    updated_by uuid
);


ALTER TABLE public.menus OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    avatar character varying(255)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: dashboard_users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboard_users (id, dashboard_id, user_id, role, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboards (id, name, description, logo, plan, is_public, is_active, created_at, updated_at, user_id) FROM stdin;
85e80933-057c-4bce-8ad5-e3c5ce1dd2f3	rahman	\N	Target	Personal	t	t	2025-01-30 08:57:50.66+00	2025-01-30 08:57:50.66+00	\N
ac1029e1-378f-4fdb-a96c-b485c1a26998	rahman	\N	Target	Personal	t	t	2025-01-30 08:59:06.768+00	2025-01-30 08:59:06.768+00	\N
4fc2a9ec-4895-4515-a82d-79707e83f7ee	new dashboard	\N	Factory	Personal	t	t	2025-01-30 08:59:28.445+00	2025-01-30 08:59:28.445+00	\N
ed22a293-ce46-4596-8291-bcfc52f69441	dashboard baru	\N	LayoutDashboard	Personal	t	t	2025-01-30 09:03:06.375+00	2025-01-30 09:03:06.375+00	\N
9f4df01e-f164-46b0-af1b-5f4e5feabcd2	Main	Default Dashboard	layout-dashboard	Personal	t	t	2025-01-30 09:05:41.998305+00	2025-01-30 09:05:41.998305+00	\N
946caaa5-144e-4238-99e9-663818de7f0f	newdb	\N	LayoutDashboard	Personal	t	t	2025-01-30 09:08:09.495+00	2025-01-30 09:08:09.495+00	\N
32303ee3-7d13-4055-aba9-eb5d06a511e6	coba	coba aja	ChevronRight	Personal	t	t	2025-01-30 09:16:33.810581+00	2025-01-30 09:16:33.810581+00	\N
6f7fe51d-d17a-4bcb-a0f4-c7e7462080d5	cobalagi	\N	Layout	Personal	t	t	2025-01-30 09:27:46.544657+00	2025-01-30 09:27:46.544657+00	\N
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_items (id, dashboard_id, parent_id, title, icon, url_href, order_index, is_active, created_at, updated_at, menu_id, is_collapsible) FROM stdin;
ad9e65b7-c48e-44e3-98b2-9a76a4a82b0e	85e80933-057c-4bce-8ad5-e3c5ce1dd2f3	\N	Overview	layout-dashboard	/dashboard	0	t	2025-01-30 09:02:16.680439+00	2025-01-30 09:02:16.680439+00	\N	f
edc71d35-56e6-4a4e-a2bc-c4a5d2dd7122	ac1029e1-378f-4fdb-a96c-b485c1a26998	\N	Overview	layout-dashboard	/dashboard	0	t	2025-01-30 09:02:16.680439+00	2025-01-30 09:02:16.680439+00	\N	f
03c7797e-edad-4a97-8e53-3b89df24ddc5	4fc2a9ec-4895-4515-a82d-79707e83f7ee	\N	Overview	layout-dashboard	/dashboard	0	t	2025-01-30 09:02:16.680439+00	2025-01-30 09:02:16.680439+00	\N	f
be83f03e-0ee9-4ed5-aefd-ad0fe74ff324	32303ee3-7d13-4055-aba9-eb5d06a511e6	\N	Overview	layout-dashboard	/dashboard	0	t	2025-01-30 09:16:34.069172+00	2025-01-30 09:16:34.069172+00	\N	f
af14e332-ad8d-41f0-b4bc-330d911c1ce5	6f7fe51d-d17a-4bcb-a0f4-c7e7462080d5	\N	Overview	layout-dashboard	/dashboard	0	t	2025-01-30 09:27:46.801944+00	2025-01-30 09:27:46.801944+00	\N	f
\.


--
-- Data for Name: menus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menus (id, dashboard_id, name, icon, menu_type, is_default, is_active, created_at, updated_at, created_by, updated_by) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, created_at, updated_at, role, avatar) FROM stdin;
b24c5f8a-5e25-4f9d-8492-9bf5f418c408	default@sadashboard.com	Default User	2025-01-30 09:31:34.005055+00	2025-01-30 10:31:27.047362+00	admin	default-avatar
\.


--
-- Name: dashboard_users dashboard_users_dashboard_id_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT dashboard_users_dashboard_id_user_id_key UNIQUE (dashboard_id, user_id);


--
-- Name: dashboard_users dashboard_users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT dashboard_users_pkey PRIMARY KEY (id);


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: menus menus_dashboard_id_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_dashboard_id_name_key UNIQUE (dashboard_id, name);


--
-- Name: menus menus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_dashboards_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_dashboards_user_id ON public.dashboards USING btree (user_id);


--
-- Name: idx_menu_items_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_dashboard_id ON public.menu_items USING btree (dashboard_id);


--
-- Name: idx_menu_items_menu_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_menu_id ON public.menu_items USING btree (menu_id);


--
-- Name: idx_menu_items_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_order ON public.menu_items USING btree (order_index);


--
-- Name: idx_menu_items_parent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_parent_id ON public.menu_items USING btree (parent_id);


--
-- Name: dashboard_users update_dashboard_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_dashboard_users_updated_at BEFORE UPDATE ON public.dashboard_users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dashboards update_dashboards_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_dashboards_updated_at BEFORE UPDATE ON public.dashboards FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: menu_items update_menu_items_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_menu_items_updated_at BEFORE UPDATE ON public.menu_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: menus update_menus_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_menus_updated_at BEFORE UPDATE ON public.menus FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: dashboard_users dashboard_users_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT dashboard_users_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: dashboard_users dashboard_users_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboard_users
    ADD CONSTRAINT dashboard_users_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: dashboards dashboards_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: menu_items fk_menu_items_menu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT fk_menu_items_menu FOREIGN KEY (menu_id) REFERENCES public.menus(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.menu_items(id) ON DELETE CASCADE;


--
-- Name: menus menus_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: menus menus_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: menus menus_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menus
    ADD CONSTRAINT menus_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--


--
-- PostgreSQL database dump
--

-- Dumped from database version 17.2 (Debian 17.2-1.pgdg120+1)
-- Dumped by pg_dump version 17.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dashboards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dashboards (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name character varying(255) NOT NULL,
    description text,
    logo character varying(255) DEFAULT 'layout-dashboard'::character varying,
    plan character varying(50) DEFAULT 'Personal'::character varying,
    is_public boolean DEFAULT false,
    is_active boolean DEFAULT true,
    menu_items jsonb DEFAULT '[]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.dashboards OWNER TO postgres;

--
-- Name: menu_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.menu_items (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    dashboard_id uuid,
    title character varying(255) NOT NULL,
    icon character varying(255),
    url jsonb,
    parent_id uuid,
    order_index integer,
    type character varying(50),
    is_active boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.menu_items OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    email character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    role character varying(50) DEFAULT 'user'::character varying NOT NULL,
    avatar character varying(255),
    default_dashboard_id uuid,
    dashboard_ids uuid[] DEFAULT '{}'::uuid[],
    dashboard_roles text[] DEFAULT '{}'::text[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: dashboards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dashboards (id, name, description, logo, plan, is_public, is_active, menu_items, created_at, updated_at) FROM stdin;
f5531af3-4bbe-4906-bc37-4b9d8f509ece	Test Dashboard	A test dashboard	layout-dashboard	Personal	t	t	[]	2025-02-01 16:03:53.441466+00	2025-02-01 16:03:53.441466+00
b24c5f8a-5e25-4f9d-8492-9bf5f418c408	Main Dashboard	Default dashboard for all users	layout-dashboard	Personal	f	t	[{"id": "menu1", "icon": "layout-dashboard", "name": "Dashboard", "path": "/dashboard", "order": 1, "parentId": null}, {"id": "menu2", "icon": "chart-bar", "name": "Analytics", "path": "/analytics", "order": 2, "parentId": null}, {"id": "menu3", "icon": "file-report", "name": "Reports", "path": "/reports", "order": 1, "parentId": "menu2"}]	2025-02-01 10:24:40.408535+00	2025-02-01 10:24:40.408535+00
\.


--
-- Data for Name: menu_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.menu_items (id, dashboard_id, title, icon, url, parent_id, order_index, type, is_active, created_at, updated_at) FROM stdin;
3877ec8e-4256-4eca-9871-77c5f807c6ab	b24c5f8a-5e25-4f9d-8492-9bf5f418c408	Dashboard	layout-dashboard	{"href": "/"}	\N	1	main	t	2025-02-01 10:24:41.843336+00	2025-02-01 10:24:41.843336+00
fdc06d5b-8b6a-413c-9815-57c600210949	b24c5f8a-5e25-4f9d-8492-9bf5f418c408	Settings	settings	{"href": "/settings"}	\N	2	main	t	2025-02-01 10:24:41.843336+00	2025-02-01 10:24:41.843336+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, name, role, avatar, default_dashboard_id, dashboard_ids, dashboard_roles, created_at, updated_at) FROM stdin;
a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11	admin@example.com	Admin User	admin	\N	b24c5f8a-5e25-4f9d-8492-9bf5f418c408	{b24c5f8a-5e25-4f9d-8492-9bf5f418c408}	{owner}	2025-02-01 10:24:39.793824+00	2025-02-01 10:24:39.793824+00
\.


--
-- Name: dashboards dashboards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dashboards
    ADD CONSTRAINT dashboards_pkey PRIMARY KEY (id);


--
-- Name: menu_items menu_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_menu_items_dashboard_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_dashboard_id ON public.menu_items USING btree (dashboard_id);


--
-- Name: idx_menu_items_parent_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_menu_items_parent_id ON public.menu_items USING btree (parent_id);


--
-- Name: menu_items menu_items_dashboard_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_dashboard_id_fkey FOREIGN KEY (dashboard_id) REFERENCES public.dashboards(id) ON DELETE CASCADE;


--
-- Name: menu_items menu_items_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.menu_items
    ADD CONSTRAINT menu_items_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.menu_items(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

